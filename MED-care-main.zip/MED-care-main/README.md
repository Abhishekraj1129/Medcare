# MED-care

Developing  a comprehensive  website for a healthcare center using HTML , Css , javascript, focusing on creating a visually appealing and informative online presence.
Designing and implementing on  a single  web pages, including sections for services, doctors, FAQs, contact information, and a signup section.
